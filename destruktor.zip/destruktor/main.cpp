#include <iostream>
#include "auta.h"

using namespace std;

int main() {
	
	Auta a1;
	a1.pokaz();
	
	return 0;
}
