#include <iostream>

using namespace std;

class Auta
{	
	string model, marka;
	int rocznik;
	char paliwo;
	
	public: 
	Auta(string="brak",string="brak",int=0,char='n');
	~Auta();
	void dodaj();
	void pokaz();	
};
