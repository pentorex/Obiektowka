#include <iostream>
#include "auta.h"

using namespace std;

void Auta::dodaj()
{
	cout<<"Podaj: \nModel: ";
	cin>>marka;
	cout<<"Model: ";
	cin>>model;
	cout<<"Rocznik: ";
	cin>>rocznik;
	cout<<"Paliwo: ";
	cin>>paliwo;
}

void Auta::pokaz()
{
	cout<<marka<<" "<<model<<" - "<<rocznik<<" - "<<paliwo<<endl;
}

Auta::Auta(string mar, string mod, int r, char p)
{
	marka=mar;
	model=mod;
	rocznik=r;
	paliwo=p;
}
Auta::~Auta()
{
	cout<<"Usunieto obiekt";
}
