#include <iostream>
#include "pytania.h"

using namespace std;

int main()
{
	Pytanie p[5];
	int suma=0;
	for(int i=0;i<=4;i++)
	{
		p[i].nr_pytania=i+1;
		p[i].wczytaj();
		p[i].zadaj_pytanie();
		p[i].sprawdz();
		suma+=p[i].punkt;
	}
	cout << "KONIEC! Twoje punkty to: " << suma << endl;

	return 0;
}
