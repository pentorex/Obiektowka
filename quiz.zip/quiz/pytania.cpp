#include <iostream>
#include "pytania.h"
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

void Pytanie::wczytaj()
{
	fstream plik;
	plik.open("quiz.txt", ios::in);

	if (plik.good() == false)
	{
		cout << "Nie udalo sie otworzyc pliku!";
		exit(0);
	}

	int nr_linii = (nr_pytania - 1) * 6 + 1;
	int nr_linii_aktualny = 1;
	string linia;

	while (getline(plik, linia))
	{
		if (nr_linii_aktualny == nr_linii)	tresc = linia;
		if (nr_linii_aktualny == nr_linii + 1) a = linia;
		if (nr_linii_aktualny == nr_linii + 2) b = linia;
		if (nr_linii_aktualny == nr_linii + 3) c = linia;
		if (nr_linii_aktualny == nr_linii + 4) d = linia;
		if (nr_linii_aktualny == nr_linii + 5) poprawna = linia;
		nr_linii_aktualny++;
	}

	plik.close();
}
void Pytanie::zadaj_pytanie()
{
	cout << tresc << endl;
	cout << "a) " << a << endl;
	cout << "b) " << b << endl;
	cout << "c) " << c << endl;
	cout << "d) " << d << endl;
	cout << "Twoja odpowiedz to: ";
	cin >> odp_udzielona;
}
void Pytanie::sprawdz()
{
	if (odp_udzielona == poprawna)
	{
		punkt = 1;
	}
	else
	{
		punkt = 0;
	}
}
