#include <iostream>

using namespace std;

class Pytanie
{
public:

	string tresc;
	string a, b, c, d;
	int nr_pytania;
	string poprawna;
	string odp_udzielona;
	int punkt;

	void wczytaj();
	void zadaj_pytanie();
	void sprawdz();

};
